# VARSHA · SIH 26072

Static, dependency-free interactive nowcasting demonstration. Open `dist/index.html` in a browser, or serve `dist` with any static HTTP server. All observations and scores are synthetic. No trained AI, live sensor data or alert distribution is implemented.

Files: `dist/index.html` (dashboard), `dist/style.css` (responsive styling), `dist/app.js` (deterministic simulation and UI), `dist/integration-plan.md` (data, ML, evaluation and service roadmap).

No installation or build step is required. Syntax check: `node --check dist/app.js`.
